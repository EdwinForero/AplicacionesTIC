/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import java.io.Serializable;

/**
 *
 * @author david
 */
public class Send implements Serializable {
    private Rubik rubik;
    private boolean negState;

    public Send(Rubik rubik, boolean negState) {
        this.rubik = rubik;
        this.negState = negState;
    }

    /**
     * @return the rubik
     */
    public Rubik getRubik() {
        return rubik;
    }

    /**
     * @param rubik the rubik to set
     */
    public void setRubik(Rubik rubik) {
        this.rubik = rubik;
    }

    /**
     * @return the negState
     */
    public boolean isNegState() {
        return negState;
    }

    /**
     * @param negState the negState to set
     */
    public void setNegState(boolean negState) {
        this.negState = negState;
    }
    
}
