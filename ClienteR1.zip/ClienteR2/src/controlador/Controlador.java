/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import interfaz.InterfazAppClient;
import mundo.Cliente;
import java.util.Arrays;
import mundo.Execution;

public class Controlador {

    private Cliente client;
    private InterfazAppClient interfazAppClient;
   
    public void conectar(InterfazAppClient interfazAppClient) {
        this.interfazAppClient = interfazAppClient;
        this.client = new Cliente(this);
        
    }

  

    public void toException(String msg) {
        System.out.println(msg);
    }

    public void run() {
        client.run();
    }
    
    

   
}
