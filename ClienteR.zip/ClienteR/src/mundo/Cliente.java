/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import controlador.Controlador;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import mundo.Send;


public class Cliente implements Runnable {


    private int portR = 6000;
    private int portS = 5000;
    private String IP = "127.0.0.2";
    private Controlador ctrl;
    private int estado = 1;
    private String outStr;

    public Cliente(Controlador ctrl) {
        this.ctrl = ctrl;
    }


    public void socket() {
        try {
            try (
                     Socket client = new Socket(IP, portS)) {
                  
                     DataOutputStream outBuffer = new DataOutputStream(client.getOutputStream());
                     outBuffer.writeUTF(outStr+"1");
                     System.out.println("Enviando la solución Cliente 1...");
 
            }
        } catch (UnknownHostException e) {
            //System.out.println("\"socket(): UnknownHostException: \" + e.getMessage()");
        } catch (IOException e) {
            //System.out.println("socket(): IOException: " + e.getMessage());

        }
    }

    @Override
    public void run() {
        ServerSocket serverSocket;
        Socket socket;
        DataInputStream inDataBuffer;
        Execution ex;
        ObjectInputStream inObjectBuffer;
        try {

            System.out.println("Listening Server from Client 1... ");
            serverSocket = new ServerSocket(portR);
            while (true) {
                socket = serverSocket.accept();
                inObjectBuffer = new ObjectInputStream(socket.getInputStream());
                Send send = (Send) inObjectBuffer.readObject();
                ex = new Execution(ctrl,send.getRubik(),send.isNegState());
                System.out.println("Recibido el objeto");
                outStr = ex.solve();
                this.socket();
                
                socket.close();
            }
        } catch (IOException e) {
            ctrl.toException("run(): IOException: " + e.getMessage());
        } catch (ClassNotFoundException ex1) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex1);
        }
    }
}
