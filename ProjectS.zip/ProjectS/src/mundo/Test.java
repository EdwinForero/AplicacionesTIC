/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import java.util.ArrayList;

/**
 *
 * @author edwin
 */
public class Test {
    public static ArrayList<Integer> padreDe(ArrayList<Integer> a, int num){
        ArrayList<Integer> padres = new ArrayList<>();
            
        while(num > 0){
            int temp = a.get(num-1);
            padres.add(temp);
            num = temp;
        }
        
        return padres;
    }
    
    public static void printArray(ArrayList<Integer> a){
        String temp = "";
        
        for(int s:a){
            temp += s + " ";
        }
        
        System.out.println("Array:\n"+temp);
    }
}
