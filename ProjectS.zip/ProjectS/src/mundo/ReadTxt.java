/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author edwin
 */
public class ReadTxt {

    public static ArrayList<Integer> readTxt(String fileName) {
        String line, vec[];
        ArrayList<Integer> in = new ArrayList<>();
        try {
            Scanner input = new Scanner(new File(fileName));

            while (input.hasNextLine()) {
                line = input.nextLine();
                vec = line.split(" ");
                process(vec, in);
                //System.out.println(vec[0] + " " + vec[1] + " " + vec[2]);          
            }
            input.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return in;
    }

    private static void process(String vec[], ArrayList<Integer> in) {
        int num = Integer.parseInt(vec[0]);
        int s = Integer.parseInt(vec[1]);
        int f = Integer.parseInt(vec[2]);

        addToArray(in, s, f, num);
    }

    private static void addToArray(ArrayList<Integer> a, int s, int f, int num) {
        for (int i = s; i <= f; i++) {
            a.add(num);
        }
    }

}
