/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 *
 * @author edwin
 */
public class MakeTxt {
    public static void makeTxt(String fileName)            
    {  try 
       { String contenido = "Contenido de ejemplo";
         File file = new File(fileName);
            
         if (!file.exists()) { file.createNewFile(); }            
         BufferedWriter buffer = new BufferedWriter(new FileWriter(fileName));
         buffer.write(contenido);
         buffer.close();
        } 
        catch (Exception e) 
        { e.printStackTrace();
        }
    }
}
