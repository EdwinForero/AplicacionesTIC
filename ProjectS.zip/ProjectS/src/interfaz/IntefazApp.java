/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author edwin
 */
import mundo.*;

public class IntefazApp {
    
    public static void main(String[] args){
        Scanner read = new Scanner(System.in);
        String path = "datos.in";
        String outPath = "datos.out";
        
        ArrayList<Integer> in = mundo.ReadTxt.readTxt(path);
        
        mundo.Test.printArray(in);
        
        int num = read.nextInt();
        
        in = Test.padreDe(in, num);
        
        mundo.Test.printArray(in);
    }
}
