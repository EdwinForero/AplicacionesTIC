package mundo;

import java.io.IOException;
import java.util.ArrayList;

public class Nonograma {

    private ArrayList<char [][]> in;

    public Nonograma() throws IOException {
        in = new ArrayList<>();
        in = util.ReadFile.leer();
    }

}
