package interfaz;

public class PanelPistas 
{

    public PanelPistas() 
    { System.out.println("PanelPistas...");
    }
    
}
