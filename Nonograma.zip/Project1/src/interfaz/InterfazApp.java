/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import controlador.Controlador;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.*;
import util.Util;

/**
 *
 * @author edwin
 */
public class InterfazApp {

    private Controlador ctrl;
    private PanelCuadricula pnlCuadricula;
    private PanelPistas pnlPistasH, pnlPistasV;
    private PanelVidas pnlVidas;

    public InterfazApp(Controlador ctrl) {

        // Enlaza el controlador	  
        this.ctrl = ctrl;

        // Instancia los paneles    
       
        pnlVidas = new PanelVidas();
        pnlCuadricula = new PanelCuadricula(ctrl, pnlVidas);
        pnlPistasH = new PanelPistas();
        pnlPistasV = new PanelPistas();

      ctrl.conectar(pnlCuadricula, pnlPistasH, pnlPistasV);
      
      

    }

    public static void main(String[] args) throws IOException {
        InterfazApp frmMain = new InterfazApp(new Controlador());
    }
}
