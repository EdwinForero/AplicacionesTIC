package interfaz;

public class PanelVidas 
{ 

    public PanelVidas() 
    { System.out.println("PanelVidas...");
    }

    public void msg()
    {
        
    }        
}

