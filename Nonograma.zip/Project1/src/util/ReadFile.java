/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
/**
 *
 * @author edwin
 */
public class ReadFile {
    public static ArrayList<char [][]> leer() throws IOException {

        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        archivo = new File("nono1.in");
        fr = new FileReader(archivo);
        br = new BufferedReader(fr);

        // Declaración variables
        String linea;
        String[] lineaE;
        byte count = 0;
        char [][] PCol = new char[5][10];
        char [][] PFila = new char[10][5];
        char [][] PTab = new char[10][10];

        //Lectura del fichero
        while ((linea = br.readLine()) != null) {
            count++;
            lineaE = linea.split(" ");
            process(lineaE, count, PCol, PFila, PTab);
        }
        
        ArrayList<char [][]> out = new ArrayList<>();
        out.add(PCol);
        out.add(PFila);
        out.add(PTab);
        
        return out;
    }

    public static void process(String[] linea, byte count, char [][] PCol, char [][] PFila, char [][] PTab) {
        char a = (char)0; //vacio
        
        if(count<=5){ //Pistas de las columnas
            for(byte f = 0; f<5; f++){
                if(PCol[f][0] == a){
                    for(byte c = 0; c<10; c++){
                        PCol[f][c] = linea[c].charAt(0);
                    }
                    break;
                }
            }
        }else if(count<=15){ //Pistas de las filas
            for(byte f = 0; f<10; f++){
                if(PFila[f][0] == a){
                    for(byte c = 0; c<5; c++){
                        PFila[f][c] = linea[c].charAt(0);
                    }
                    break;
                }
            }
        }else{ //Pistas del tablero
            for(byte f = 0; f<10; f++){
                if(PTab[f][0] == a){
                    for(byte c = 0; c<10; c++){
                        PTab[f][c] = linea[c].charAt(0);
                    }
                    break;
                }
            }
        }
    }
    
    public static void ImprimirMatriz(char[][] a){
        String linea = "";
        for(byte f = 0; f<a.length; f++){
            for(byte c = 0; c<a[f].length; c++){
                 linea += a[f][c] + " ";
            }
            System.out.println(linea);
            linea = "";
        }
    }
}
