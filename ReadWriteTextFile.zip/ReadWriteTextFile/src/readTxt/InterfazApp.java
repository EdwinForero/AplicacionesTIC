package readTxt;


import java.io.File;
import java.util.Scanner;

public class InterfazApp 
{
    public static void main(String[] args) 
    { readTxt("data/datos.in");        
    }

    public static void readTxt(String fileName)
    { String line, vec[];        
    
      try 
      { Scanner input = new Scanner(new File(fileName));
        while (input.hasNextLine()) 
        { line = input.nextLine();
          vec = line.split(" ");
          System.out.println(vec[0] + " " + vec[1] + " " + vec[2]);          
        }
        input.close();       
      } 
      catch (Exception ex) 
      { ex.printStackTrace();
      }    	
    }       
}
