package makeTxt;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;


public class InterfazApp 
{

    public static void main(String[] args) 
    { makeTxt("data/datos.out");  
    }

    public static void makeTxt(String fileName)            
    {  try 
       { String contenido = "Contenido de ejemplo";
         File file = new File(fileName);
            
         if (!file.exists()) { file.createNewFile(); }            
         BufferedWriter buffer = new BufferedWriter(new FileWriter(fileName));
         buffer.write(contenido);
         buffer.close();
        } 
        catch (Exception e) 
        { e.printStackTrace();
        }
    }                
}

