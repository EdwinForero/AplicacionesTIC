/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mundo;

import controlador.Controlador;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author contr
 */
public class Server implements Runnable {

    private int portS = 6000;
    private int portS1 = 7000;
    private int portR = 5000;
    private String IP = "127.0.0.1";
    private Controlador ctrl;
    private String send = "";

    public Server(Controlador ctrl) {
        this.ctrl = ctrl;
    }

    public void socket(Send send) {
        try {
            try (Socket server = new Socket(IP, portS)) {
                ObjectOutputStream outBuffer = new ObjectOutputStream(server.getOutputStream());
                outBuffer.writeObject(send);
                System.out.println("Enviandole objeto al cliente 1");

            }
        } catch (UnknownHostException e) {
            ctrl.toException("socket(): UnknownHostException: \" + e.getMessage()");
        } catch (IOException e) {
            ctrl.toException("socket(): IOException: " + e.getMessage());

        }
    }

    public void socket1(Send send) {
        try {
            try (Socket server = new Socket(IP, portS1)) {
                ObjectOutputStream outBuffer = new ObjectOutputStream(server.getOutputStream());
                outBuffer.writeObject(send);
                System.out.println("Enviandole objeto al cliente 2");

            }
        } catch (UnknownHostException e) {
            ctrl.toException("socket(): UnknownHostException: \" + e.getMessage()");
        } catch (IOException e) {
            ctrl.toException("socket(): IOException: " + e.getMessage());

        }
    }

    public void receive() {
        ServerSocket serverSocket;
        Socket socket;
        DataInputStream inDataBuffer;

        try {
            System.out.println("Listening Client...");
            serverSocket = new ServerSocket(portR);
            while (true) {
                socket = serverSocket.accept();
                inDataBuffer = new DataInputStream(socket.getInputStream());
                send = inDataBuffer.readUTF();
                System.out.println("Troll?: " + send);
                if (!send.isEmpty()) {
                    System.out.println("Recibiendo la solución...");
                    ctrl.getExe().setLst(send);
                    ctrl.getExe().start();
                    send = null;
                }
                inDataBuffer.readUTF();
                socket.close();
            }
        } catch (IOException e) {
            //ctrl.toException("receive() server: IOException: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        receive();
    }

    public String getSend() {
        return send;
    }

}
